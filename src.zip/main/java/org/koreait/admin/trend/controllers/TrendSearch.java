package org.koreait.admin.trend.controllers;

import lombok.Data;

@Data
public class TrendSearch {
    private String siteUrl;
}

package org.koreait.product.constants;

public enum ProductStatus {
    READY,
    SALE,
    OUT_OF_STOCK,
    STOP
}

package org.koreait.member.constants;

public enum Authority {
    MEMBER, // 일반회원
    ADMIN   // 관리자
}

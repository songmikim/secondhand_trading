package org.koreait.member.social.constants;

public enum SocialType {
    NONE,
    KAKAO,
    NAVER
}

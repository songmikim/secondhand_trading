package org.koreait.file.constants;

public enum FileStatus {
    ALL,
    DONE,  // 그룹작업 완료 파일만
    UNDONE // 그룹작업이 미완료된 파일만
}

import type { Chart, ChartMeta, TRBL } from '../types/index.js';
export declare function getDatasetClipArea(chart: Chart, meta: ChartMeta): TRBL | false;
